"""Membuat suara narator pria (Microsoft Neural, bukan Google) untuk tiap baris di src/lines.json.
Hasilnya: public/voice/<id>.mp3 dan src/durations.json (dipakai agar teks dan animasi pas dengan suara)."""
import asyncio, json, os
import edge_tts
from mutagen.mp3 import MP3

VOICE = "id-ID-ArdiNeural"   # suara pria Indonesia
RATE = "-4%"                  # sedikit lebih santai
lines = json.load(open("src/lines.json", encoding="utf-8"))

async def main():
    os.makedirs("public/voice", exist_ok=True)
    durs = {}
    for l in lines:
        path = f"public/voice/{l['id']}.mp3"
        await edge_tts.Communicate(l["text"], VOICE, rate=RATE).save(path)
        durs[l["id"]] = round(MP3(path).info.length, 2)
        print("ok", l["id"], durs[l["id"]], "detik")
    json.dump({"ready": True, "durations": durs}, open("src/durations.json", "w"), indent=1)
    print("Selesai. Suara siap dipakai.")

asyncio.run(main())
