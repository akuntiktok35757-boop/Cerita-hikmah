"""Membuat efek suara dan musik latar sederhana (tanpa internet) ke public/sfx/*.wav"""
import math, random, struct, wave, os
SR = 22050
random.seed(7)
N = lambda s: int(SR * s)
def noise(n): return [random.uniform(-1, 1) for _ in range(n)]
def lp(x, a):
    y = 0.0; o = []
    for v in x:
        y += a * (v - y); o.append(y)
    return o
def hp(x, a): return [v - w for v, w in zip(x, lp(x, a))]
def env(n, d): return [math.exp(-i / (SR * d)) for i in range(n)]
def mul(a, b): return [x * y for x, y in zip(a, b)]
def tone(f0, f1, d, kind="sin", vib=0):
    n = N(d); ph = 0.0; o = []
    for i in range(n):
        f = f0 + (f1 - f0) * i / n + (vib * math.sin(i / SR * 40) if vib else 0)
        ph += 2 * math.pi * f / SR
        o.append(math.sin(ph) if kind == "sin" else (ph / (2 * math.pi)) % 1 * 2 - 1)
    return o
def blank(d): return [0.0] * N(d)
def place(out, sig, t, g=1.0):
    s = N(t)
    for i, v in enumerate(sig):
        if s + i < len(out): out[s + i] += v * g
def save(name, x, peak=0.9):
    m = max(1e-9, max(abs(v) for v in x))
    os.makedirs("public/sfx", exist_ok=True)
    with wave.open(f"public/sfx/{name}.wav", "w") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(v / m * peak * 32767)) for v in x))

def step():
    n = N(.14)
    a = mul(lp(noise(n), .12), env(n, .03)); b = mul(tone(110, 60, .14), env(n, .05))
    return [x * 2 + y for x, y in zip(a, b)]
def steps(iv, c):
    o = blank(iv * c + .2)
    for k in range(c): place(o, step(), k * iv, .8 + .2 * random.random())
    return o
save("steps", steps(.42, 8)); save("run", steps(.22, 14))

n = N(.3); save("shock", mul(tone(350, 1500, .3), [min(1, i / 200) * math.exp(-i / (SR * .25)) for i in range(n)]))
n = N(1.0); save("crash", [x * 1.5 + y for x, y in zip(mul(lp(noise(n), .4), env(n, .35)), mul(tone(140, 40, 1.0), env(n, .25)))])

o = blank(1.2); place(o, mul(hp(noise(N(.2)), .3), env(N(.2), .05)), 0)
for _ in range(18):
    t = random.random() * .7; f = random.uniform(2500, 6500); d = random.uniform(.05, .12)
    place(o, mul(tone(f, f, d), env(N(d), d / 3)), t, .35)
save("glass", o)

n = N(.7); z = noise(n); out = []; y = 0.0
for i in range(n):
    p = i / n; a = .03 + .4 * math.sin(math.pi * p); y += a * (z[i] - y); out.append(y * math.sin(math.pi * p))
save("whoosh", out)

def bk():
    n = N(.18); s = lp(tone(260, 170, .18, "saw"), .25); r = lp(noise(n), .3)
    e = [min(1, i / 150) * math.exp(-i / (SR * .07)) for i in range(n)]
    return mul([a * .7 + b * .5 for a, b in zip(s, r)], e)
o = blank(.6); place(o, bk(), 0); place(o, bk(), .26, .9); save("bark", o)

save("pop", mul(tone(500, 1000, .12), env(N(.12), .04)))
n = N(1.4)
save("ding", mul([sum(h * math.sin(2 * math.pi * f * i / SR) for f, h in ((880, 1), (1760, .4), (2640, .2))) for i in range(n)], env(n, .5)))

n = N(2.4); s = lp(tone(55, 60, 2.4, "saw"), .08); r = lp(noise(n), .02)
save("bus", [(a * .6 + b * 3) * (1 + .35 * math.sin(2 * math.pi * 13 * i / SR)) for i, (a, b) in enumerate(zip(s, r))])
n = N(.6); save("screech", mul(lp(tone(1500, 2400, .6, "saw"), .35), [min(1, i / 400) * (1 - i / n) for i in range(n)]))

o = blank(1.6)
for k, f in enumerate((392, 370, 349, 310)):
    d = .34 if k < 3 else .6
    place(o, mul(tone(f, f * .99, d, "sin", vib=(8 if k == 3 else 0)), env(N(d), d * 1.2)), k * .34)
save("sad", o)

beat = 60 / 100
def pluck(f, d=.7):
    n = N(d)
    return mul([math.sin(2 * math.pi * f * i / SR) + .3 * math.sin(4 * math.pi * f * i / SR) for i in range(n)], [min(1, i / 80) * math.exp(-i / (SR * .22)) for i in range(n)])
ch = [((261.6, 329.6, 392.0), 130.8), ((220.0, 261.6, 329.6), 110.0), ((174.6, 220.0, 261.6), 87.3), ((196.0, 246.9, 293.7), 98.0)]
o = blank(len(ch) * 4 * beat * 2); t = 0
for _ in range(2):
    for notes, bass in ch:
        place(o, mul(tone(bass, bass, beat * 3.5), env(N(beat * 3.5), 1.2)), t, .9)
        for k in range(8): place(o, pluck(notes[[0, 1, 2, 1][k % 4]]), t + k * beat / 2, .5)
        t += beat * 4
save("music", o, .7)
print("Efek suara selesai")
