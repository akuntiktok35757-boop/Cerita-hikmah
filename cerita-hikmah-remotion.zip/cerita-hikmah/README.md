# Cerita Hikmah (Remotion)

1. `npm install`
2. `npm run voice`   (membuat suara narator pria, perlu internet)
3. `npm run dev`     (pratinjau di Remotion Studio)
4. Render: tombol roket di Studio, atau `npm run build` (hasil di folder out)

Ganti teks narasi di `src/lines.json`, lalu jalankan `npm run voice` lagi.
Ingin pakai suara sendiri? Rekam tiap baris, simpan sebagai public/voice/<id>.mp3 (id ada di lines.json),
lalu isi src/durations.json dengan "ready": true dan durasi tiap file (detik).
