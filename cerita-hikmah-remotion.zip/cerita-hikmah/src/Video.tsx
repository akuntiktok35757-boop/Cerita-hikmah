import React from "react";
import {
  AbsoluteFill, Audio, Easing, Sequence, interpolate, random, spring, staticFile,
  useCurrentFrame, useVideoConfig,
} from "remotion";
import lines from "./lines.json";
import dur from "./durations.json";

const W = 1920, H = 1080, FPS = 30, PAD = 20;
const FONT = "'Segoe UI','Helvetica Neue',Roboto,Arial,sans-serif";
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const lerp = (f: number, a: number, b: number, x: number, y: number, e?: (t: number) => number) =>
  interpolate(f, [a, b], [x, y], {...clamp, easing: e});

const frames = lines.map((l) => Math.ceil(((dur.durations as Record<string, number>)[l.id] ?? 4) * FPS) + PAD);
const starts: number[] = [];
let acc = 0;
frames.forEach((n) => { starts.push(acc); acc += n; });
export const TOTAL_FRAMES = acc;

/* ---------- Suara & kamera ---------- */
const Sfx: React.FC<{at: number; src: string; vol?: number; len?: number; loop?: boolean}> = ({at, src, vol = 1, len, loop}) => (
  <Sequence from={Math.round(at)} durationInFrames={len ? Math.round(len) : undefined}>
    <Audio src={staticFile(`sfx/${src}.wav`)} volume={vol} loop={loop} />
  </Sequence>
);

const Cam: React.FC<{from?: number; to?: number; ox?: number; oy?: number; punch?: number; children: React.ReactNode}> = ({from = 1, to = 1.12, ox = 50, oy = 60, punch, children}) => {
  const f = useCurrentFrame();
  const {durationInFrames: d} = useVideoConfig();
  let sc = interpolate(f, [0, d], [from, to], clamp);
  let sh = 0;
  if (punch !== undefined && f >= punch) {
    const k = Math.max(0, 1 - (f - punch) / 24);
    sc += 0.2 * k;
    sh = Math.sin(f * 2.7) * 12 * k;
  }
  return <AbsoluteFill style={{transform: `translate(${sh}px,${sh * 0.6}px) scale(${sc})`, transformOrigin: `${ox}% ${oy}%`}}>{children}</AbsoluteFill>;
};

const Svg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: "absolute", left: 0, top: 0}}>{children}</svg>
);

/* ---------- Tokoh ---------- */
type Face = "happy" | "shock" | "sad" | "worry" | "relief" | "angry";
type PP = {x: number; y?: number; s?: number; flip?: boolean; face?: Face; pose?: "idle" | "walk" | "run" | "up"; shirt?: string; pants?: string; skin?: string; hair?: string; mask?: boolean; old?: boolean; rot?: number; opacity?: number; speed?: number};
const ST = {stroke: "#3A2A20", strokeWidth: 5, fill: "none", strokeLinecap: "round"} as const;

const Person: React.FC<PP> = ({x, y = 800, s = 1, flip = false, face = "happy", pose = "idle", shirt = "#FF6B6B", pants = "#3B4A6B", skin = "#FFD3A8", hair = "#3A2A20", mask = false, old = false, rot = 0, opacity = 1, speed = 1}) => {
  const f = useCurrentFrame();
  const run = pose === "run", walk = pose === "walk" || run, up = pose === "up";
  const ph = f * (run ? 0.75 : 0.42) * speed, A = run ? 48 : walk ? 26 : 0, sw = Math.sin(ph) * A;
  const bob = walk ? -Math.abs(Math.sin(ph)) * (run ? 16 : 8) : up ? -Math.abs(Math.sin(f * 0.25)) * 14 : Math.sin(f * 0.12) * 3;
  const aL = up ? 150 + Math.sin(f * 0.5) * 14 : -sw * (run ? 1.2 : 1);
  const aR = up ? -150 - Math.sin(f * 0.5 + 1) * 14 : old ? -10 : sw * (run ? 1.2 : 1);
  const blink = f % 110 < 4, sh = face === "shock";
  const bi = face === "worry" || face === "sad" ? -296 : face === "angry" ? -282 : sh ? -304 : -290;
  const bo = face === "worry" || face === "sad" ? -284 : face === "angry" ? -296 : sh ? -304 : -290;
  const arc = face === "happy" || face === "relief";
  const mouth =
    face === "happy" ? <path d="M-24,-238 Q0,-208 24,-238" {...ST} /> :
    face === "relief" ? <path d="M-24,-238 Q0,-194 24,-238Z" fill="#8B2E2E" stroke="#3A2A20" strokeWidth={4} /> :
    sh ? <ellipse cy={-224} rx={13} ry={20} fill="#8B2E2E" stroke="#3A2A20" strokeWidth={4} /> :
    face === "sad" ? <path d="M-20,-222 Q0,-244 20,-222" {...ST} /> :
    face === "worry" ? <path d="M-22,-226 Q-11,-236 0,-226 Q11,-216 22,-226" {...ST} /> :
    <path d="M-20,-226 L20,-226" {...ST} />;
  return (
    <g transform={`translate(${x},${y}) scale(${flip ? -s : s},${s}) rotate(${rot})`} opacity={opacity}>
      <ellipse cy={4} rx={62} ry={10} fill="#0002" />
      {[1, -1].map((k) => (
        <g key={k} transform={`translate(${k * 20},${-112 + bob}) rotate(${sw * k})`}>
          <rect x={-11} y={0} width={22} height={92} rx={11} fill={pants} />
          <ellipse cx={8} cy={100} rx={24} ry={11} fill="#2B2B2B" />
        </g>
      ))}
      <g transform={`translate(0,${bob}) rotate(${run ? 8 : old ? 9 : 0} 0 -110)`}>
        {[-1, 1].map((k) => (
          <g key={k} transform={`translate(${k * 50},-196) rotate(${k === 1 ? aR : aL})`}>
            <rect x={-10} y={0} width={20} height={88} rx={10} fill={shirt} />
            <circle cy={92} r={13} fill={skin} />
            {old && k === 1 && <rect x={-3} y={84} width={6} height={96} rx={3} fill="#8B5A2B" />}
          </g>
        ))}
        <rect x={-46} y={-212} width={92} height={112} rx={32} fill={shirt} />
        <circle cx={-62} cy={-262} r={12} fill={skin} /><circle cx={62} cy={-262} r={12} fill={skin} />
        <circle cy={-265} r={62} fill={skin} />
        <path d="M-64,-268 Q-68,-348 0,-344 Q68,-348 64,-268 Q40,-304 0,-300 Q-40,-304 -64,-268Z" fill={hair} />
        {old && <circle cy={-350} r={24} fill={hair} />}
        <path d={`M-40,${bo} L-14,${bi}`} {...ST} /><path d={`M14,${bi} L40,${bo}`} {...ST} />
        {arc ? (
          <><path d="M-36,-256 Q-25,-274 -14,-256" {...ST} /><path d="M14,-256 Q25,-274 36,-256" {...ST} /></>
        ) : (
          [-25, 25].map((ex) => (
            <g key={ex} transform={`translate(${ex},-262) scale(1,${blink ? 0.1 : 1})`}>
              <circle r={sh ? 17 : 12} fill="#fff" stroke="#3A2A20" strokeWidth={3} /><circle cx={3} r={sh ? 4 : 7} fill="#222" />
            </g>
          ))
        )}
        {mask && <g><rect x={-58} y={-280} width={116} height={34} rx={12} fill="#111" /><ellipse cx={-24} cy={-263} rx={9} ry={6} fill="#fff" /><ellipse cx={24} cy={-263} rx={9} ry={6} fill="#fff" /></g>}
        {(face === "happy" || face === "relief") && <><circle cx={-42} cy={-240} r={10} fill="#FF8FA3" opacity={0.5} /><circle cx={42} cy={-240} r={10} fill="#FF8FA3" opacity={0.5} /></>}
        {!mask && mouth}
        {mask && <path d="M-20,-226 L20,-226" {...ST} />}
        {(face === "worry" || sh) && <path d={`M62,${-312 + (f % 20)} q-10,16 0,22 q10,-6 0,-22`} fill="#6EC6FF" />}
      </g>
    </g>
  );
};

const Dog: React.FC<{x: number; y?: number; s?: number; flip?: boolean; run?: boolean; face?: "happy" | "bark" | "sad"; carry?: boolean; skinny?: boolean}> = ({x, y = 800, s = 1, flip = false, run = false, face = "happy", carry = false, skinny = false}) => {
  const f = useCurrentFrame();
  const sw = run ? Math.sin(f * 0.8) * 40 : 0, wag = Math.sin(f * 0.9) * (run ? 10 : 28);
  return (
    <g transform={`translate(${x},${y}) scale(${flip ? -s : s},${s})`}>
      <ellipse cy={4} rx={90} ry={10} fill="#0002" />
      {[[-55, sw], [-35, -sw], [45, -sw], [65, sw]].map(([lx, a], i) => (
        <g key={i} transform={`translate(${lx},-60) rotate(${a})`}>
          <rect x={-8} width={16} height={62} rx={8} fill="#B97A3E" /><ellipse cx={4} cy={64} rx={14} ry={7} fill="#8A5A2B" />
        </g>
      ))}
      <g transform={`translate(-78,-85) rotate(${-40 + wag})`}><rect x={-6} y={-50} width={12} height={55} rx={6} fill="#B97A3E" /></g>
      <ellipse cy={-85} rx={85} ry={skinny ? 36 : 46} fill="#C98B4A" />
      {skinny && [-30, -10, 10].map((rx) => <path key={rx} d={`M${rx},-100 Q${rx + 8},-85 ${rx},-70`} stroke="#8A5A2B" strokeWidth={4} fill="none" />)}
      <circle cx={90} cy={-120} r={42} fill="#C98B4A" />
      <ellipse cx={70} cy={-140} rx={14} ry={28} fill="#8A5A2B" transform="rotate(20 70 -140)" />
      <ellipse cx={128} cy={-108} rx={24} ry={17} fill="#E8B77B" />
      <circle cx={146} cy={-114} r={8} fill="#222" />
      <circle cx={104} cy={-128} r={7} fill="#222" />
      {face === "sad" && <path d="M92,-146 L116,-138" stroke="#222" strokeWidth={4} />}
      {face === "bark" && <path d="M112,-100 L146,-96 L128,-80Z" fill="#8B2E2E" />}
      {face === "happy" && <ellipse cx={130} cy={-92} rx={8} ry={12} fill="#FF8FA3" />}
      {carry && <rect x={118} y={-102} width={36} height={26} rx={5} fill="#7B4A1E" />}
    </g>
  );
};

/* ---------- Properti ---------- */
const Cloud: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`} fill="#fff" opacity={0.9}>
    <circle r={40} /><circle cx={50} cy={-14} r={52} /><circle cx={105} r={38} /><rect x={-40} width={185} height={38} rx={19} />
  </g>
);

const Backdrop: React.FC<{kind: "day" | "park" | "dusk"}> = ({kind}) => {
  const f = useCurrentFrame();
  const dusk = kind === "dusk";
  const bc = dusk ? ["#5B4A8A", "#6D5A9C", "#4E3F7A"] : ["#BFD8E8", "#D7C8E8", "#C9E3D2"];
  const hs = [260, 380, 300, 430, 320, 360];
  return (
    <g>
      <defs>
        <linearGradient id={"g" + kind} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={dusk ? "#FF9E7A" : "#7FD1FF"} /><stop offset="1" stopColor={dusk ? "#7B5EA7" : "#EAF8FF"} />
        </linearGradient>
      </defs>
      <rect width={W} height={H} fill={`url(#g${kind})`} />
      <circle cx={dusk ? 1500 : 260} cy={dusk ? 520 : 150} r={78} fill={dusk ? "#FFD39B" : "#FFE066"} />
      {[0, 1, 2].map((i) => <Cloud key={i} x={((i * 760 + f * (0.5 + i * 0.25)) % 2500) - 300} y={90 + i * 80} />)}
      {kind === "park" ? (
        <>
          <ellipse cx={500} cy={780} rx={900} ry={260} fill="#7ED36B" /><ellipse cx={1500} cy={800} rx={900} ry={240} fill="#62C25A" />
          <rect x={1590} y={430} width={50} height={350} fill="#8B5A2B" />
          <circle cx={1615} cy={410} r={130} fill="#3F9B46" /><circle cx={1530} cy={470} r={90} fill="#4FB24B" /><circle cx={1700} cy={470} r={90} fill="#4FB24B" />
          <rect y={790} width={W} height={300} fill="#4FB24B" />
        </>
      ) : (
        <>
          {hs.map((h, i) => <rect key={i} x={i * 330 - 20} y={700 - h} width={300} height={h} fill={bc[i % 3]} />)}
          <rect y={700} width={W} height={100} fill="#D8D8DE" />
          <rect y={800} width={W} height={280} fill="#4A4F5C" />
          {Array.from({length: 12}).map((_, i) => <rect key={i} x={i * 180 + 40} y={960} width={90} height={12} fill="#F5F5F5" />)}
        </>
      )}
    </g>
  );
};

const Bus: React.FC<{x: number; y: number; s?: number; rot?: number}> = ({x, y, s = 1, rot = 0}) => {
  const f = useCurrentFrame();
  return (
    <g transform={`translate(${x},${y}) scale(${s}) rotate(${rot})`}>
      <rect x={-260} y={-230} width={520} height={190} rx={36} fill="#FFC21A" />
      <rect x={-260} y={-110} width={520} height={24} fill="#E8A200" />
      {[-215, -140, -65, 10, 85].map((wx) => <rect key={wx} x={wx} y={-205} width={62} height={70} rx={10} fill="#BFE9FF" />)}
      <rect x={165} y={-205} width={70} height={90} rx={10} fill="#BFE9FF" />
      {[-150, 150].map((cx) => (
        <g key={cx} transform={`translate(${cx},-40) rotate(${f * 14})`}>
          <circle r={42} fill="#222" /><circle r={20} fill="#999" /><rect x={-3} y={-20} width={6} height={40} fill="#555" />
        </g>
      ))}
    </g>
  );
};

const Building: React.FC = () => (
  <g>
    <rect x={1280} y={40} width={520} height={750} fill="#E9B8A0" />
    {[130, 350, 570].map((wy) => [1320, 1610].map((wx) => <rect key={wx + "-" + wy} x={wx} y={wy} width={90} height={130} rx={8} fill="#BFE9FF" stroke="#B88A74" strokeWidth={6} />))}
    <rect x={1420} y={300} width={160} height={16} fill="#777" />
    {[1430, 1470, 1510, 1550, 1570].map((rx) => <rect key={rx} x={rx} y={250} width={5} height={50} fill="#777" />)}
    <rect x={1450} y={680} width={100} height={110} rx={8} fill="#7B4A1E" />
  </g>
);

const Pot: React.FC<{x: number; y: number; rot?: number}> = ({x, y, rot = 0}) => (
  <g transform={`translate(${x},${y}) rotate(${rot})`}>
    <path d="M-34,-60 L34,-60 L26,0 L-26,0Z" fill="#C8643C" /><rect x={-38} y={-72} width={76} height={16} rx={6} fill="#D9774C" />
    <path d="M0,-72 Q-6,-110 0,-130" stroke="#3F9B46" strokeWidth={6} fill="none" />
    <circle cy={-136} r={20} fill="#FF5C8A" /><circle cy={-136} r={8} fill="#FFD84D" />
  </g>
);

const Shards: React.FC<{x: number; y: number; t: number}> = ({x, y, t}) => {
  if (t < 0) return null;
  return (
    <g>
      {Array.from({length: 12}).map((_, i) => {
        const a = -Math.PI * (0.15 + 0.7 * random("a" + i)), v = 14 + 10 * random("v" + i);
        const py = y + Math.sin(a) * v * t + 0.5 * 1.2 * t * t;
        return <polygon key={i} points="0,-14 12,10 -12,8" fill={i % 2 ? "#C8643C" : "#D9774C"} transform={`translate(${x + Math.cos(a) * v * t},${Math.min(py, y)}) rotate(${i * 40 + t * 20})`} />;
      })}
      {Array.from({length: 5}).map((_, i) => <circle key={i} cx={x + (i - 2) * 34 * (1 + t * 0.05)} cy={y - 10 - t * 0.8} r={18 + t * 1.2} fill="#E8E0D5" opacity={Math.max(0, 0.8 - t / 30)} />)}
    </g>
  );
};

const Burst: React.FC<{x: number; y: number; text: string; at: number}> = ({x, y, text, at}) => {
  const f = useCurrentFrame();
  if (f < at) return null;
  const p = spring({frame: f - at, fps: FPS, config: {damping: 7, stiffness: 180}});
  const pts = Array.from({length: 24}, (_, i) => { const a = (i * Math.PI) / 12, r = i % 2 ? 110 : 200; return `${Math.cos(a) * r},${Math.sin(a) * r}`; }).join(" ");
  return (
    <g transform={`translate(${x},${y}) scale(${p}) rotate(-8)`}>
      <polygon points={pts} fill="#FFD84D" stroke="#FF5C3A" strokeWidth={10} />
      <text textAnchor="middle" y={18} fontSize={54} fontWeight={900} fill="#FF5C3A" stroke="#fff" strokeWidth={8} paintOrder="stroke">{text}</text>
    </g>
  );
};

const Heart: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <path d="M0,0 C-20,-24 -50,-2 0,34 C50,-2 20,-24 0,0Z" fill="#FF5C8A" transform={`translate(${x},${y}) scale(${s})`} />
);

/* ---------- Kartu hikmah, teks, transisi ---------- */
const Hik: React.FC<{title: string; sub: string; children?: React.ReactNode}> = ({title, sub, children}) => {
  const f = useCurrentFrame();
  const p = spring({frame: f - 4, fps: FPS, config: {damping: 11}});
  return (
    <>
      <Cam from={1} to={1.06} oy={40}>
        <Svg>
          <rect width={W} height={H} fill="#FFF6D6" />
          <g transform={`translate(960,300) rotate(${f * 0.3})`}>
            {Array.from({length: 14}).map((_, i) => <polygon key={i} points="0,0 -60,-1000 60,-1000" fill="#FFE98A" opacity={0.55} transform={`rotate(${(i * 360) / 14})`} />)}
          </g>
          <g transform={`translate(960,260) scale(${p})`} textAnchor="middle">
            <circle r={70} fill="#FFD84D" stroke="#12302F" strokeWidth={8} /><rect x={-28} y={66} width={56} height={34} rx={8} fill="#12302F" />
            <text y={190} fontSize={80} fontWeight={900} fill="#12302F">{title}</text>
            <text y={262} fontSize={46} fill="#5B7472">{sub}</text>
          </g>
          {children}
        </Svg>
      </Cam>
      <Sfx at={4} src="ding" vol={0.8} />
    </>
  );
};

const Sub: React.FC<{text: string; total: number}> = ({text, total}) => {
  const f = useCurrentFrame();
  const w = text.split(" "), idx = Math.min(w.length - 1, Math.floor((f / Math.max(1, total)) * w.length));
  return (
    <div style={{position: "absolute", left: 100, right: 100, bottom: 50, textAlign: "center", fontSize: 44, fontWeight: 800, lineHeight: 1.25, background: "rgba(10,25,30,.66)", borderRadius: 28, padding: "16px 30px", fontFamily: FONT}}>
      {w.map((t, i) => <span key={i} style={{display: "inline-block", marginRight: 12, color: i === idx ? "#FFD84D" : "#fff", transform: i === idx ? "scale(1.08)" : "none"}}>{t}</span>)}
    </div>
  );
};

/* ---------- Adegan ---------- */
const Intro: React.FC = () => {
  const f = useCurrentFrame();
  const p = spring({frame: f - 6, fps: FPS, config: {damping: 9}});
  return (
    <>
      <Cam from={1} to={1.1} oy={50}>
        <Svg>
          <Backdrop kind="day" />
          <g transform={`translate(960,300) scale(${p})`} textAnchor="middle" fontWeight={900} stroke="#12302F" strokeWidth={14} paintOrder="stroke">
            <text fontSize={118} fill="#fff">3 Kisah Kecil</text><text y={130} fontSize={118} fill="#FFD84D">Hikmah Besar</text>
          </g>
          <Person x={960} y={800} s={1.2} pose="up" face="happy" />
        </Svg>
      </Cam>
      <Sfx at={0} src="whoosh" vol={0.5} /><Sfx at={6} src="pop" />
    </>
  );
};

const B1: React.FC = () => {
  const f = useCurrentFrame();
  const bx = lerp(f, 0, 95, 120, 1020, Easing.out(Easing.quad));
  const busX = f < 30 ? 1000 : 1000 + 0.9 * (f - 30) ** 2;
  const running = f < 95;
  return (
    <>
      <Cam from={1} to={1.15} ox={55}>
        <Svg>
          <Backdrop kind="day" />
          <rect x={1040} y={560} width={10} height={240} fill="#555" /><circle cx={1045} cy={540} r={40} fill="#2F5BEA" stroke="#fff" strokeWidth={6} />
          {f > 30 && [0, 1, 2, 3].map((i) => <rect key={i} x={busX - 330 - i * 40} y={620 + i * 30} width={120} height={6} rx={3} fill="#fff" opacity={0.7} />)}
          <Bus x={busX} y={800} />
          <Person x={bx} y={800} pose={running ? "run" : "idle"} face={running ? "worry" : "angry"} rot={running ? 0 : Math.sin(f * 1.5) * 3} />
        </Svg>
      </Cam>
      <Sfx at={0} src="run" len={95} vol={0.6} /><Sfx at={0} src="bus" len={80} vol={0.5} /><Sfx at={36} src="whoosh" vol={0.6} /><Sfx at={100} src="sad" vol={0.8} />
    </>
  );
};

const B2: React.FC = () => {
  const f = useCurrentFrame();
  const busX = lerp(f, 0, 62, 700, 1500), tilt = f > 62 ? spring({frame: f - 62, fps: FPS, config: {damping: 8}}) * -14 : 0;
  const t = Math.max(0, f - 72);
  return (
    <>
      <Cam from={1} to={1.12} ox={30} punch={72}>
        <Svg>
          <Backdrop kind="day" />
          <Bus x={busX} y={720} s={0.5} rot={tilt} />
          {f > 72 && [0, 1, 2, 3, 4].map((i) => <circle key={i} cx={1460 + i * 25} cy={620 - t * (1.5 + i * 0.3)} r={26 + t * 0.5} fill="#9AA3AE" opacity={Math.max(0, 0.8 - t / 90)} />)}
          <Burst x={1450} y={430} text="BRAAAK!" at={72} />
          <Person x={520} y={800} pose={f > 74 && f < 118 ? "up" : "idle"} face={f < 62 ? "sad" : f < 118 ? "shock" : "relief"} />
        </Svg>
      </Cam>
      <Sfx at={60} src="screech" vol={0.7} /><Sfx at={70} src="crash" vol={0.7} /><Sfx at={74} src="shock" vol={0.8} />
    </>
  );
};

const B3: React.FC = () => (
  <Hik title="Terlambat belum tentu sial" sub="Kadang itu cara kita dilindungi"><Person x={960} y={850} s={0.95} face="relief" /></Hik>
);

const N1: React.FC = () => {
  const f = useCurrentFrame();
  const {durationInFrames: d} = useVideoConfig();
  const x = lerp(f, 0, d - 20, 280, 1080);
  const wob = f > d - 50 ? Math.sin(f * 1.3) * 6 : 0;
  return (
    <>
      <Cam from={1} to={1.12} ox={40}>
        <Svg>
          <Backdrop kind="day" />
          {Array.from({length: 10}).map((_, i) => <rect key={i} x={250 + i * 95} y={815} width={50} height={235} fill="#EEE" />)}
          <Building /><Pot x={1500} y={300} rot={wob} />
          <Person x={x - 130} y={850} pose="walk" speed={0.7} face="happy" />
          <Person x={x} y={850} s={0.88} old pose="walk" speed={0.6} face="happy" shirt="#B07CC6" pants="#6B4E8A" hair="#E5E5E5" skin="#F2C7A0" />
        </Svg>
      </Cam>
      <Sfx at={0} src="steps" len={d} loop vol={0.55} />
    </>
  );
};

const N2: React.FC = () => {
  const f = useCurrentFrame();
  const S = 40, L = 73, potY = f < S ? 300 : 300 + 0.45 * (f - S) ** 2, landed = f >= L;
  const wob = f < S ? (f > 12 ? Math.sin(f * 1.1) * 9 : 0) : (f - S) * 7;
  const face: Face = landed ? "shock" : "happy";
  return (
    <>
      <Cam from={1} to={1.1} ox={60} oy={60} punch={L}>
        <Svg>
          <Backdrop kind="day" />
          <Building />
          {f >= S && !landed && <ellipse cx={1500} cy={792} rx={lerp(f, S, L, 6, 70)} ry={10} fill="#000" opacity={0.3} />}
          {!landed && <Pot x={1500} y={Math.min(potY, 790)} rot={wob} />}
          <Person x={1500} y={790} pose="idle" opacity={landed ? lerp(f, L, L + 10, 0.4, 0) : 0.4} />
          {landed && <Shards x={1500} y={790} t={f - L} />}
          <Burst x={1500} y={480} text="PRANG!" at={L} />
          <Person x={800} y={850} face={face} pose="idle" />
          <Person x={930} y={850} s={0.88} old face={face} pose="idle" shirt="#B07CC6" pants="#6B4E8A" hair="#E5E5E5" skin="#F2C7A0" />
        </Svg>
      </Cam>
      <Sfx at={S} src="whoosh" vol={0.5} /><Sfx at={L} src="glass" /><Sfx at={L} src="crash" vol={0.5} /><Sfx at={L + 3} src="shock" vol={0.8} />
    </>
  );
};

const N3: React.FC = () => (
  <Hik title="Berbuat baik melindungi kita" sub="tanpa kita sadari">
    <Person x={860} y={850} s={0.95} face="happy" /><Person x={1060} y={850} s={0.85} old face="happy" shirt="#B07CC6" pants="#6B4E8A" hair="#E5E5E5" skin="#F2C7A0" />
  </Hik>
);

const D1: React.FC = () => {
  const f = useCurrentFrame();
  const fly = lerp(f, 46, 80, 0, 1);
  const bx = 730 + fly * 500, by = 680 - Math.sin(Math.PI * fly) * 170 + fly * 20;
  const t = Math.max(0, f - 88);
  return (
    <>
      <Cam from={1} to={1.12} ox={60}>
        <Svg>
          <Backdrop kind="park" />
          <Person x={640} y={800} face="happy" />
          {f < 80 && <ellipse cx={f < 46 ? 730 : bx} cy={f < 46 ? 680 : by} rx={30} ry={18} fill="#E0A458" stroke="#B9772F" strokeWidth={4} />}
          <Dog x={1250} y={800} flip skinny={f < 80} face={f < 80 ? "sad" : "happy"} />
          {f > 88 && [0, 1, 2].map((i) => <Heart key={i} x={1180 + i * 50} y={600 - t * (1 + i * 0.3)} s={Math.max(0, 1 - t / 80)} />)}
        </Svg>
      </Cam>
      <Sfx at={46} src="pop" /><Sfx at={92} src="bark" vol={0.7} />
    </>
  );
};

const D2: React.FC = () => {
  const f = useCurrentFrame();
  const {durationInFrames: d} = useVideoConfig();
  const F = f / d;
  const tx = F < 0.2 ? 1000 - (F / 0.2) * 300 : F < 0.62 ? 700 + (F - 0.2) * 1500 : 1330;
  const fall = F >= 0.62, trot = fall ? Math.min(85, (F - 0.62) * 900) : 0;
  const dx = F < 0.3 ? -150 : F < 0.62 ? -150 + ((F - 0.3) / 0.32) * 1430 : F < 0.8 ? 1280 : 1280 - ((F - 0.8) / 0.2) * 620;
  const wx = F < 0.2 ? 550 : F < 0.26 ? lerp(F, 0.2, 0.26, 550, tx + 55) : F < 0.62 ? tx + 55 : lerp(F, 0.62, 0.78, tx + 55, 1450);
  const wy = F < 0.2 ? 690 : F < 0.26 ? 685 : F < 0.62 ? 680 : 790 - Math.sin(Math.PI * Math.min(1, (F - 0.62) / 0.16)) * 120;
  const budiFace: Face = F < 0.2 ? "happy" : F < 0.7 ? "shock" : "relief";
  return (
    <>
      <Cam from={1} to={1.08} punch={Math.round(0.2 * d)}>
        <Svg>
          <Backdrop kind="dusk" />
          <Person x={500} y={800} face={budiFace} pose={F >= 0.2 && F < 0.7 ? "up" : "idle"} />
          {F < 0.8 && <g transform={`translate(${wx},${wy})`}><rect width={36} height={26} rx={5} fill="#7B4A1E" /><rect x={4} y={10} width={28} height={4} fill="#D9A441" /></g>}
          <Person x={tx} y={800} shirt="#2B2B2B" pants="#444" hair="#222" mask pose={F < 0.2 ? "walk" : fall ? "idle" : "run"} face={fall ? "worry" : "angry"} rot={trot} />
          <Dog x={dx} y={800} run={F >= 0.3 && F < 0.62 || F >= 0.8} flip={F >= 0.8} carry={F >= 0.8} face={F > 0.6 && F < 0.75 ? "bark" : "happy"} />
        </Svg>
      </Cam>
      <Sfx at={0.2 * d} src="shock" vol={0.8} /><Sfx at={0.2 * d} src="run" len={0.4 * d} vol={0.5} /><Sfx at={0.6 * d} src="bark" vol={0.8} /><Sfx at={0.62 * d} src="crash" vol={0.4} /><Sfx at={0.88 * d} src="ding" vol={0.6} />
    </>
  );
};

const D3: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Hik title="Kebaikan tidak pernah sia-sia" sub="sekecil apa pun">
      <Person x={780} y={850} s={0.95} face="happy" /><Dog x={1100} y={850} flip face="happy" />
      {[0, 1, 2].map((i) => <Heart key={i} x={960 + i * 70} y={600 - ((f * 1.2 + i * 40) % 140)} s={0.8} />)}
    </Hik>
  );
};

const O1: React.FC = () => {
  const f = useCurrentFrame();
  const p = spring({frame: f - 4, fps: FPS, config: {damping: 10}});
  const cols = ["#FF5C8A", "#FFD84D", "#2F5BEA", "#2BA38B", "#FF8A3D"];
  return (
    <>
      <Cam from={1} to={1.08}>
        <Svg>
          <Backdrop kind="day" />
          <g transform={`translate(960,280) scale(${p})`} textAnchor="middle" fontWeight={900} stroke="#12302F" strokeWidth={12} paintOrder="stroke">
            <text fontSize={96} fill="#fff">Setiap kejadian</text><text y={110} fontSize={96} fill="#FFD84D">punya hikmah</text>
          </g>
          <Person x={960} y={800} s={1.2} pose="up" face="happy" />
          {Array.from({length: 40}).map((_, i) => <rect key={i} x={random("cx" + i) * W} y={((f * (3 + random("cs" + i) * 3) + random("cy" + i) * 1200) % 1300) - 100} width={16} height={26} fill={cols[i % 5]} transform={`rotate(${f * 6 + i * 30} ${random("cx" + i) * W} 0)`} />)}
        </Svg>
      </Cam>
      <Sfx at={4} src="pop" /><Sfx at={20} src="ding" vol={0.7} />
    </>
  );
};

const SCENES: Record<string, React.FC> = {intro: Intro, b1: B1, b2: B2, b3: B3, n1: N1, n2: N2, n3: N3, d1: D1, d2: D2, d3: D3, o1: O1};

const FadeIn: React.FC<{children: React.ReactNode}> = ({children}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{opacity: lerp(f, 0, 6, 0, 1)}}>{children}</AbsoluteFill>;
};

export const Cerita: React.FC = () => (
  <AbsoluteFill style={{background: "#000", fontFamily: FONT}}>
    <Audio src={staticFile("sfx/music.wav")} loop volume={0.12} />
    {lines.map((l, i) => {
      const Scene = SCENES[l.id];
      return (
        <Sequence key={l.id} from={starts[i]} durationInFrames={frames[i]}>
          <FadeIn><Scene /></FadeIn>
          <Sub text={l.text} total={frames[i] - PAD} />
          {dur.ready && <Audio src={staticFile(`voice/${l.id}.mp3`)} />}
        </Sequence>
      );
    })}
  </AbsoluteFill>
);
